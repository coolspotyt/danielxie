# Daniel Xie — Website

The complete portfolio, ready for manual upload. No installation or build step is required.

## Upload

1. Extract the ZIP.
2. Upload all files and folders inside `daniel-xie-website` to your repository or website hosting directory.
3. Keep `index.html` at the top level and preserve the `assets` and `licenses` folders.

The asset links are relative, so the site can run at a domain root or within a project subdirectory. Uploading code to GitHub does not by itself enable website hosting.

## Files

- `index.html`: all page content and video embeds.
- `styles.css` and `luxury.css`: layout, colors, typography, and effects.
- `script.js`, `effects.js`, and `loader.js`: navigation, motion, corn dog cursor, and film-reel loader.
- `assets/`: every photo, logo, and decorative image used by the site.
- `favicon.svg`: film-reel browser icon.
- `licenses/`: included third-party license notices.

## Edit and preview

Edit the HTML, CSS, and JavaScript files directly. For a local preview, run `python3 -m http.server 8000` from this folder and open `http://localhost:8000`.

YouTube, Instagram, and Google Fonts require an internet connection. Video embeds depend on the platforms allowing playback; direct source links are included.

## Image notes

The full set of approved images is included. Hidden EXIF, XMP, IPTC, and JPEG comment metadata were removed from the photo copies without changing their pixels or color profiles. The corn dog illustration was generated for this portfolio. The film-reel icon is adapted from Phosphor Icons; its MIT license is included.
